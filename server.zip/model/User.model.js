// import mongoose from "mongoose";

// export const UserSchema = new mongoose.Schema({
//     // username: {
//     //     type: String,
//     //     required: [true, "Please provide unique Username"],
//     //     unique: [true, "Username Exist"]
//     // },
//     email: {
//         type: String,
//         required: [true, "Please provide a unique email"],
//         unique: [true, "Same Email already Exist, try with another one."]
//     },
//     password: {
//         type: String,
//         required: [true, "Please provide a password"],
//         unique: false,
//     },
//     // email: {
//     //     type: String,
//     //     required: [true, "Please provide a unique email"],
//     //     unique: true,
//     // },
//     firstname: { type: String },
//     lastname: { type: String },
//     mobile: { type: Number },
//     address: { type: String },
//     profile: { type: String },
//     role: { type: String, enum: ['user', 'admin'], default: 'user' } // Adding role field

// });

// export default mongoose.model.Users || mongoose.model('User', UserSchema);

import mongoose from "mongoose";

export const UserSchema = new mongoose.Schema({
    email: {
        type: String,
        required: [true, "Please provide a unique email"],
        unique: true // Email should be unique
    },
    password: {
        type: String,
        required: [true, "Please provide a password"],
        unique: false, // Password does not need to be unique
    },
    firstname: {
        type: String
    },
    lastname: {
        type: String
    },
    mobile: {
        type: Number
    },
    address: {
        type: String
    },
    profile: {
        type: String
    },
    role: {
        type: String,
        enum: ['user', 'admin'],
        default: 'user' // Default role is 'user'
    }
});

// Export the model
// export default mongoose.model('User', UserSchema);
export default mongoose.model.Users || mongoose.model('User', UserSchema);