export default {
    JWT_SECRET: "4bb5f8410c2209ed95734b1b98c4b23071cc5151096b1eba071d52f9b8a6fce4",
    EMAIL: "paris.bernier@ethereal.email",
    PASSWORD: "NRuh4WKSchSNRGESev",
    ATLAS_URI: "mongodb+srv://srnitish06:admin123456@cluster0.nmxeypl.mongodb.net/?retryWrites=true&w=majority"
}