npm init -y
npm install express cors mongoose mongodb-memory-server multer nodemon morgon

https://www.youtube.com/watch?v=BfrJxGQEPSc


require('crypto').randomBytes(32).toString('hex')
4bb5f8410c2209ed95734b1b98c4b23071cc5151096b1eba071d52f9b8a6fce4